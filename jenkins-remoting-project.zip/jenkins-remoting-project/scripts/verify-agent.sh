#!/usr/bin/env bash
set -euo pipefail

echo "=== Jenkins Agent Environment Verification ==="
echo

echo "Hostname:"
hostname
echo

echo "Operating system:"
uname -a
echo

echo "Current user:"
whoami
echo

echo "Java:"
java -version
echo

echo "Working directory:"
pwd
echo

echo "Disk:"
df -h .
echo

echo "Verification complete."
