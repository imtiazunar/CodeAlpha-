# Jenkins Windows Agent preparation script.
# Run PowerShell as Administrator.
#
# This script creates a dedicated local user and agent directory.
# It does not store Jenkins passwords, tokens, or private keys.

$JenkinsUser = "jenkins-agent"
$AgentDirectory = "C:\Jenkins\agent"

Write-Host "Preparing Windows Jenkins agent..." -ForegroundColor Cyan

$ExistingUser = Get-LocalUser -Name $JenkinsUser -ErrorAction SilentlyContinue

if (-not $ExistingUser) {
    Write-Host "Creating local user: $JenkinsUser"
    $Password = Read-Host "Enter a password for the dedicated agent user" -AsSecureString
    New-LocalUser -Name $JenkinsUser -Password $Password -Description "Jenkins build agent account"
} else {
    Write-Host "User already exists: $JenkinsUser"
}

if (-not (Test-Path $AgentDirectory)) {
    New-Item -ItemType Directory -Path $AgentDirectory -Force | Out-Null
}

Write-Host "Agent directory: $AgentDirectory"

Write-Host "`nJava version:" -ForegroundColor Yellow
java -version

Write-Host "`nNext step:" -ForegroundColor Yellow
Write-Host "Create the Jenkins node and configure the appropriate agent launch method."
