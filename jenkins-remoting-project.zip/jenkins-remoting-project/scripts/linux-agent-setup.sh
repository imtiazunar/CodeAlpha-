#!/usr/bin/env bash
set -euo pipefail

# Jenkins Linux Agent preparation script.
# Run with sudo on the Linux machine.
#
# This script prepares a dedicated user and workspace.
# It does not contain or generate Jenkins credentials.

JENKINS_USER="${JENKINS_USER:-jenkins}"
JENKINS_HOME="${JENKINS_HOME:-/home/jenkins/agent}"

echo "Preparing Linux Jenkins agent..."

if ! id "$JENKINS_USER" >/dev/null 2>&1; then
    sudo useradd --create-home --shell /bin/bash "$JENKINS_USER"
    echo "Created user: $JENKINS_USER"
else
    echo "User already exists: $JENKINS_USER"
fi

sudo mkdir -p "$JENKINS_HOME"
sudo chown -R "$JENKINS_USER:$JENKINS_USER" "$JENKINS_HOME"

echo "Java version:"
java -version

echo
echo "Agent user:"
id "$JENKINS_USER"

echo
echo "Remote root directory:"
echo "$JENKINS_HOME"

echo
echo "Next step:"
echo "Create the node in Jenkins and configure the appropriate launch method."
