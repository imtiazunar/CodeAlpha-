# Jenkins Remoting Project

## Internship Task 2

This project demonstrates how Jenkins Remoting can be used to connect a Jenkins Controller with remote Jenkins Agents, distribute build workloads, execute jobs on different operating systems/architectures, and improve security through node isolation.

## Objectives

- Set up Jenkins Remoting between a controller and remote agents.
- Distribute build workloads across different machines.
- Run jobs remotely on different environments.
- Use labels to target specific Jenkins nodes.
- Apply basic node-isolation and credential-security practices.
- Gain hands-on experience with Jenkins remote execution.

## Architecture

```text
                    +----------------------+
                    |   Jenkins Controller |
                    |     / Controller      |
                    +----------+-----------+
                               |
                         Jenkins Remoting
                               |
              +----------------+----------------+
              |                                 |
      +-------v--------+                +-------v--------+
      | Linux Agent    |                | Windows Agent  |
      | label: linux   |                | label: windows |
      +----------------+                +----------------+
              |                                 |
          Build/Test                         Build/Test
```

## Repository Structure

```text
jenkins-remoting-project/
├── README.md
├── Jenkinsfile
├── docker-compose.yml
├── .gitignore
├── scripts/
│   ├── linux-agent-setup.sh
│   ├── windows-agent-setup.ps1
│   └── verify-agent.sh
├── pipeline/
│   ├── Jenkinsfile-linux
│   └── Jenkinsfile-windows
├── config/
│   └── agent-config.example.yml
├── docs/
│   ├── architecture.md
│   ├── setup-guide.md
│   └── security.md
└── screenshots/
    └── .gitkeep
```

## Prerequisites

- Jenkins Controller
- One or more remote machines
- Java/JDK supported by the Jenkins version being used
- Network connectivity between controller and agents
- SSH access for SSH-based Linux agents, or the appropriate Jenkins agent launch method
- Administrator privileges during initial machine setup

> Always check the Jenkins documentation for the Java versions supported by your installed Jenkins release.

## Basic Setup

1. Install Jenkins on the controller.
2. Prepare a Linux or Windows machine as an agent.
3. Create a dedicated agent user where practical.
4. Open Jenkins and create a permanent node.
5. Set the agent's remote root directory.
6. Assign a label such as `linux-agent` or `windows-agent`.
7. Configure the launch method.
8. Connect the agent and verify that it becomes online.
9. Run one of the Pipeline examples in this repository.
10. Confirm from the console output that the build ran on the selected remote node.

Detailed instructions are in `docs/setup-guide.md`.

## Pipeline Examples

### Linux

The Linux Pipeline runs commands such as:

```text
uname -a
java -version
```

and demonstrates execution on a node labeled:

```text
linux-agent
```

### Windows

The Windows Pipeline uses:

```text
systeminfo
java -version
```

and demonstrates execution on a node labeled:

```text
windows-agent
```

## Security

This repository intentionally contains no real passwords, private keys, Jenkins API tokens, or other secrets.

Recommended practices:

- Use Jenkins Credentials for secrets.
- Use a dedicated account for agents.
- Avoid running agents as root/Administrator unless there is a documented requirement.
- Restrict network access with firewalls.
- Keep Jenkins, Java, and operating systems updated.
- Isolate agents according to trust level.
- Use labels to control where workloads execute.
- Do not commit `.pem`, `.key`, passwords, tokens, or secret environment files.

See `docs/security.md`.

## Verification

After connecting an agent, verify:

- Node status is `Online`.
- The node has the expected label.
- A Pipeline starts on the selected agent.
- Console output identifies the remote environment.
- Multiple agents can execute jobs independently.

## Screenshots

Add internship screenshots to the `screenshots/` folder, for example:

```text
01-controller.png
02-node-configuration.png
03-agent-online.png
04-linux-build.png
05-windows-build.png
06-console-output.png
```

Do not include screenshots containing passwords, private keys, API tokens, or other confidential information.

## Learning Outcomes

This project provides practical experience with:

- Jenkins Controller/Agent architecture
- Jenkins Remoting
- Remote job execution
- Pipeline labels
- Distributed builds
- Cross-platform build environments
- Agent isolation
- Jenkins credential security

## Author

**Imtiaz Ali Unar**

Internship Task 2 — Jenkins Remoting Project
