# Jenkins Remoting Security

## 1. Dedicated Agent Accounts

Use a dedicated operating-system account for Jenkins agents instead of a personal account whenever practical.

Avoid running agents with unnecessary administrator/root privileges.

## 2. Credentials

Store credentials in Jenkins Credentials Management.

Do not place secrets directly inside:

- Jenkinsfiles
- shell scripts
- PowerShell scripts
- YAML files
- README files
- Git history

## 3. Network Security

Restrict network access between the controller and agents to the ports and protocols required by the selected launch method.

Use firewalls and network segmentation where appropriate.

## 4. Node Isolation

Agents should be separated based on workload requirements and trust level.

For example:

```text
Trusted internal builds
        |
        +---- Dedicated trusted agent

Untrusted/test builds
        |
        +---- Isolated agent
```

Avoid mixing highly trusted workloads with untrusted workloads on the same agent.

## 5. Software Updates

Keep the following updated:

- Jenkins
- Jenkins plugins
- Java/JDK
- Operating system
- Build tools

Review Jenkins security advisories and update according to your organization's maintenance process.

## 6. Secrets in Console Logs

Do not print credentials or secret values.

When credentials are required, use Jenkins credentials features rather than hard-coding them.

## 7. Repository Safety

This project uses example configuration only. Before publishing to GitHub, verify:

```bash
git status
git diff
```

and make sure no secret files are staged.

## Security Goal

The objective is to ensure that remote build execution is controlled, authenticated, isolated, and limited to the permissions required for the assigned workload.
