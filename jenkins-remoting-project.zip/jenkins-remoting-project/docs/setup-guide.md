# Jenkins Remoting Setup Guide

## 1. Prepare the Controller

Install Jenkins on the controller machine and complete the initial setup.

Create an administrator account and install the required Pipeline and agent-related plugins recommended by your Jenkins installation.

## 2. Prepare a Linux Agent

Run:

```bash
chmod +x scripts/linux-agent-setup.sh
./scripts/linux-agent-setup.sh
```

The script creates a dedicated agent account and workspace.

Make sure Java is installed and supported by your Jenkins release.

## 3. Create a Jenkins Node

In Jenkins:

```text
Manage Jenkins
    -> Nodes
    -> New Node
```

Example:

```text
Name: linux-agent-1
Type: Permanent Agent
Remote root directory: /home/jenkins/agent
Labels: linux-agent
```

Choose the appropriate launch method. For a Linux machine, SSH-based agent launch is a common option.

## 4. Prepare a Windows Agent

Open PowerShell as Administrator and run:

```powershell
.\scripts\windows-agent-setup.ps1
```

Create a Jenkins node with a remote root such as:

```text
C:\Jenkins\agent
```

Use the label:

```text
windows-agent
```

Choose the agent launch method appropriate for your environment.

## 5. Verify the Connection

The node should become online in Jenkins.

Run the Linux or Windows Pipeline in this repository and inspect the Jenkins console output.

## 6. Test Remote Execution

For Linux:

```text
pipeline/Jenkinsfile-linux
```

For Windows:

```text
pipeline/Jenkinsfile-windows
```

The output should show information about the remote operating system, host, user, and Java installation.

## 7. Troubleshooting

### Agent is offline

Check:

- network connectivity
- firewall rules
- Java installation
- Jenkins agent logs
- SSH configuration if SSH is being used
- permissions on the remote root directory

### Label not found

Make sure the Pipeline label exactly matches the label configured on the Jenkins node.

### Permission denied

Verify that the dedicated agent account owns the remote root directory and has only the permissions required by the build.

## Important

Do not copy passwords, private SSH keys, Jenkins secrets, or API tokens into this repository.
