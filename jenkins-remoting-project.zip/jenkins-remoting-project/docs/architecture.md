# Jenkins Remoting Architecture

## Components

### Jenkins Controller

The controller manages Jenkins configuration, schedules jobs, stores job information, and coordinates work.

### Jenkins Agent

An agent is a separate machine that executes build, test, packaging, or deployment steps assigned by Jenkins.

### Jenkins Remoting

Jenkins uses its agent/remoting mechanism to communicate with agents and send work for execution.

## Example Topology

```text
                        Jenkins Controller
                              |
                         Agent Connection
                              |
          +-------------------+-------------------+
          |                                       |
   Linux Agent                                Windows Agent
   linux-agent                                windows-agent
          |                                       |
   Linux build/test                         Windows build/test
```

## Labels

Labels allow a Pipeline to select an appropriate node.

Example:

```groovy
agent {
    label 'linux-agent'
}
```

This tells Jenkins that the stage should run on an agent matching the `linux-agent` label.

## Node Isolation

Different agents can be separated according to:

- operating system
- architecture
- workload type
- trust level
- installed tools
- network access

This can reduce the impact of a compromised or incorrectly configured build environment.
