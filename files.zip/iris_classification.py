"""
Iris Flower Classification
---------------------------
Internship Task: Classify Iris flowers (Setosa, Versicolor, Virginica) based on
sepal/petal measurements using Scikit-learn.

Steps covered:
1. Load the Iris dataset
2. Explore the data (EDA)
3. Split into train/test sets
4. Train several classification models
5. Evaluate accuracy and performance
6. Save the best model, plots, and a metrics report
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # no display needed, just save files
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
os.makedirs(OUT_DIR, exist_ok=True)

RANDOM_STATE = 42

# -----------------------------------------------------------------------
# 1. Load the dataset
# -----------------------------------------------------------------------
# Scikit-learn ships the classic Iris dataset (originally from the UCI
# Machine Learning Repository), so no manual download / internet access
# is required. It contains 150 samples, 4 features, and 3 species.
iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target, name="species")
species_names = dict(enumerate(iris.target_names))
y_named = y.map(species_names)

# Save a CSV copy of the raw dataset for reference / submission
df = X.copy()
df["species"] = y_named
df.to_csv(os.path.join(OUT_DIR, "iris_dataset.csv"), index=False)

print("Dataset shape:", df.shape)
print("\nClass distribution:")
print(y_named.value_counts())
print("\nSummary statistics:")
print(df.describe())

# -----------------------------------------------------------------------
# 2. Exploratory Data Analysis (EDA)
# -----------------------------------------------------------------------
sns.set_theme(style="whitegrid")

# Pairplot: shows how well the 3 species separate across feature pairs
pairplot_df = df.copy()
pp = sns.pairplot(pairplot_df, hue="species", diag_kind="hist", palette="Set2")
pp.fig.suptitle("Iris Feature Pairplot by Species", y=1.02)
pp.savefig(os.path.join(OUT_DIR, "01_pairplot.png"), dpi=150, bbox_inches="tight")
plt.close("all")

# Correlation heatmap
plt.figure(figsize=(6, 5))
sns.heatmap(X.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "02_correlation_heatmap.png"), dpi=150)
plt.close()

# Boxplots per feature, split by species
fig, axes = plt.subplots(2, 2, figsize=(11, 8))
for ax, col in zip(axes.ravel(), X.columns):
    sns.boxplot(data=df, x="species", y=col, hue="species", palette="Set2", ax=ax, legend=False)
    ax.set_title(col)
plt.suptitle("Feature Distributions by Species")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "03_feature_boxplots.png"), dpi=150)
plt.close()

# -----------------------------------------------------------------------
# 3. Train / test split
# -----------------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
print(f"\nTrain size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")

# Feature scaling (helps distance-based / gradient-based models like KNN, SVM, LogReg)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# -----------------------------------------------------------------------
# 4. Train several classification models and compare them
# -----------------------------------------------------------------------
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=5),
    "Support Vector Machine": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE),
    "Decision Tree": DecisionTreeClassifier(random_state=RANDOM_STATE),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE),
}

results = []
fitted_models = {}

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    preds = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, preds)
    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5)
    results.append(
        {
            "model": name,
            "test_accuracy": acc,
            "cv_mean_accuracy": cv_scores.mean(),
            "cv_std": cv_scores.std(),
        }
    )
    fitted_models[name] = model

results_df = pd.DataFrame(results).sort_values("test_accuracy", ascending=False)
results_df.to_csv(os.path.join(OUT_DIR, "model_comparison.csv"), index=False)
print("\nModel comparison:")
print(results_df.to_string(index=False))

# Plot model comparison
plt.figure(figsize=(8, 5))
sns.barplot(data=results_df, x="test_accuracy", y="model", hue="model", palette="viridis", legend=False)
plt.xlim(0, 1.05)
plt.xlabel("Test Accuracy")
plt.title("Model Comparison on Iris Test Set")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "04_model_comparison.png"), dpi=150)
plt.close()

# -----------------------------------------------------------------------
# 5. Evaluate the best model in detail
# -----------------------------------------------------------------------
best_model_name = results_df.iloc[0]["model"]
best_model = fitted_models[best_model_name]
best_preds = best_model.predict(X_test_scaled)

acc = accuracy_score(y_test, best_preds)
report = classification_report(y_test, best_preds, target_names=iris.target_names)
cm = confusion_matrix(y_test, best_preds)

print(f"\nBest model: {best_model_name}")
print(f"Test Accuracy: {acc:.4f}")
print("\nClassification Report:")
print(report)

# Confusion matrix plot
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=iris.target_names)
fig, ax = plt.subplots(figsize=(6, 5))
disp.plot(ax=ax, cmap="Blues", colorbar=False)
plt.title(f"Confusion Matrix — {best_model_name}")
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "05_confusion_matrix.png"), dpi=150)
plt.close()

# Feature importance (for tree-based models)
if hasattr(best_model, "feature_importances_"):
    importances = pd.Series(best_model.feature_importances_, index=X.columns).sort_values()
    plt.figure(figsize=(7, 4))
    importances.plot(kind="barh", color="seagreen")
    plt.title(f"Feature Importance — {best_model_name}")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "06_feature_importance.png"), dpi=150)
    plt.close()

# -----------------------------------------------------------------------
# 6. Save the trained model + scaler for reuse
# -----------------------------------------------------------------------
joblib.dump(best_model, os.path.join(OUT_DIR, "best_iris_model.joblib"))
joblib.dump(scaler, os.path.join(OUT_DIR, "scaler.joblib"))

# Save a text summary report
with open(os.path.join(OUT_DIR, "results_summary.txt"), "w") as f:
    f.write("IRIS FLOWER CLASSIFICATION - RESULTS SUMMARY\n")
    f.write("=" * 50 + "\n\n")
    f.write(f"Dataset: {df.shape[0]} samples, {X.shape[1]} features, 3 classes\n")
    f.write(f"Train/Test split: {X_train.shape[0]} / {X_test.shape[0]} (80/20, stratified)\n\n")
    f.write("Model comparison (test accuracy):\n")
    f.write(results_df.to_string(index=False) + "\n\n")
    f.write(f"Best model: {best_model_name}\n")
    f.write(f"Test Accuracy: {acc:.4f}\n\n")
    f.write("Classification Report:\n")
    f.write(report)

print(f"\nAll outputs saved to: {OUT_DIR}")
